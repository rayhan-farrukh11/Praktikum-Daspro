
a = input()
b = input()

if ord(a) >= 65 and ord(b) <= 90 and ord(a) >= 65 and ord(b) <= 90:
    sin = ord(b) - ord(a)
    if sin < 0:
        sin = abs(sin)
    if sin > 13:
        sin = 26 - sin


    print(sin)

else:
    print('Tidak Valid')
