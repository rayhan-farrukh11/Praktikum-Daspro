n = int(input())
a = list(map(int, input().strip().split()))

maxValue = -999999
for i in range(n):
    if a[i] > maxValue:
        maxValue = a[i]
minValue = 9999999
for i in range(n):
    if a[i] < maxValue:
        minValue = a[i]
tabFrek = [0 for _ in range(maxValue+1)]
for i in range(n):
    for j in range(maxValue+1):
        if a[i] == j:
            tabFrek[j] += 1
maxCount = -999
for i in range(1,maxValue+1):
    if tabFrek[i] > maxCount:
        maxCount = tabFrek[i]
        z = i 
print(z)